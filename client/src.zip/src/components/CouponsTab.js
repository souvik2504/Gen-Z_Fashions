import React, { useEffect, useState } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { Copy, CheckCircle, XCircle } from 'lucide-react';

const CouponsTab = () => {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(null);

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/loyalty/status', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setCoupons(response.data.claimedCoupons);
    } catch (error) {
      toast.error('Failed to load coupons');
    } finally {
      setLoading(false);
    }
  };

  const copyCode = (code) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    toast.success('Coupon code copied');
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="p-4">
      <h3 className="text-xl font-semibold mb-4 text-black dark:text-white">My Coupons</h3>

      {loading ? (
        <p className="text-black dark:text-white">Loading coupons...</p>
      ) : coupons.length === 0 ? (
        <p className="text-black dark:text-white">You have no coupons yet.</p>
      ) : (
        <ul className="space-y-4">
          {coupons.map((coupon) => {
            const expired = new Date(coupon.expiresAt) < new Date();
            const used = coupon.usedAt != null;
            
            return (
              <li
                key={coupon.code}
                className={`flex items-center justify-between p-4 rounded-lg border ${
                  expired ? 'bg-gray-200 dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-500 dark:text-gray-400 line-through' : 'bg-green-50 dark:bg-green-900 border-green-400 text-green-800 dark:text-green-300'
                }`}
              >
                <div>
                  <code className="font-mono text-lg tracking-widest select-all">{coupon.code}</code>
                  <div className="text-sm">{coupon.surprise}</div>
                  <div className="text-xs mt-1">Expires: {new Date(coupon.expiresAt).toLocaleDateString()}</div>
                  {used && <div className="text-xs font-semibold text-red-600 dark:text-red-400">Used</div>}
                </div>
                <button
                  onClick={() => copyCode(coupon.code)}
                  disabled={expired || used}
                  title={expired ? "Coupon expired" : used ? "Coupon used" : "Copy code"}
                  className={`p-2 rounded text-green-800 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-800 transition-colors ${
                    expired || used ? 'cursor-not-allowed opacity-50' : ''
                  }`}
                >
                  {copied === coupon.code ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};

export default CouponsTab;
